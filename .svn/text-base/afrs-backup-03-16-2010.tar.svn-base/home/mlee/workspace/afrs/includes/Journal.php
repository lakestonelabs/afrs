<?php

include("includes/MysqlDbConnection.php");

Class Journal
{
	function __construct()
	{
		
	}
	
	function writeEntry()
	{
		
	}
	
	function removeEntry()
	{
		
	}
}
?>