<?php
require("conf/afrs_config.php");
require_once("includes/database/DbConnectionWrapper.php");
require_once("includes/database/QueryWrapper.php");

// Returns
function get_ip_addresses()
{
	
	$device_elements_array = array();
	$device_collumns = null;  // Stores the number of collums.
	$device_count = null;
	$device_names = array();
	$route_entries_count = null;
	$device_array = array(); // Actually holds the computed information for the various network devices.
	
	$output = shell_exec("/sbin/route");
	$route_array = preg_split("/\n/", $output);  // Split the output into an array delimited by newlines.
	
	foreach($route_array as $route_line)  // Find the dev names and store them in the 2d array.
	{
		echo "ROUTE LINE: " . $route_line . "\n";
		$device_elements = preg_split("/ +/", $route_line);
		$device_elements_array[] = $device_elements;
	}
	array_pop($device_elements_array); // Get rid of the trailing last new line.
	$device_elements_array = array_reverse($device_elements_array);
	array_pop($device_elements_array); //Get rid of the description.
	array_pop($device_elements_array); // Get rid of the headers.
	$device_elements_array = array_reverse($device_elements_array); // Put the array back in order.
	
	$device_collumns = sizeof($device_elements_array[0]);
	$route_entries_count = sizeof($device_elements_array);
	
	// Get the device names.
	for($i = 0; $i < $route_entries_count; $i++)
	{
		if (!in_array($device_elements_array[$i][$device_collumns-1], $device_names))
		{
			$device_names[] = $device_elements_array[$i][$device_collumns-1];
		}
	}
	
	print_r($device_elements_array);
	echo "Collumn count is: " . $device_collumns . "\n";
	print_r($device_names);
	//echo $output;
}

function get_ip_address_db()
{
	$db_conn = new DbConnectionWrapper($dbtype, $dbhost, $dbname, $dbuser, $dbpassword);  // TODO  Need to figure out why I can't use the vars from the config include.
	$query = new QueryWrapper($this->db_conn);
	$query->runQuery("select value from tbl_inet_devices where status = 1");
	$result = $query->getResultAssoc();
	return $result["ip"];
}

function createRandomPassword($length) 
{
    $chars = "abcdef023456789";
    srand((double)microtime()*1000000);
    $i = 0;
    $pass = '' ;

    while ($i < $length) 
    {
        $num = rand() % 33;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }
    return $pass;
}

function getSID()  // Gets the SID for this server.  The SID is used as the client_id in to remote partners.
{
	$db_conn = new DbConnectionWrapper("mysql", "localhost", "afrs", "afrs", "afrspassword");  // TODO  Need to figure out why I can't use the vars from the config include.
	$query = new QueryWrapper($db_conn);
	
	if ($query->runQuery("select value from tbl_registry where name = 'sid'"))
	{
		if ($query->getResultSize() > 0)
		{
			$result = $query->getResultAssoc();
			return $result["value"];
		}
		else
		{
			return (false);
		}
	}
	else
	{
		return (false);
	}
	
}

function createhash()
{
	return(hash('md5', microtime()));
}
?>