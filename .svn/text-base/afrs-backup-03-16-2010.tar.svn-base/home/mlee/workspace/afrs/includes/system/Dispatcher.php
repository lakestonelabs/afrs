<?php

require_once("includes/database/DbConnectionWrapper.php");
require_once("includes/database/QueryWrapper.php");
//require_once("includes/network/StreamSocketServer.php");  // Needed to reply to the client.  No object of the type is ever instantiated in the Dispatcher.
require_once("includes/system/Message.php");
require_once("includes/functions.php");

Class Dispatcher
{
	private $transaction_obj = null,
			$message_obj = null,
			$dispatch_db_conn = null,
			$dispatch_query = null;
	
	function __construct()
	{
		require("conf/afrs_config.php");  // Variables are out of scope if outside a function and outside a class declaration in Classes.
		$this->dispatch_db_conn = new DbConnectionWrapper($dbtype, $dbhost, $dbname, $dbuser, $dbpassword);
		$this->dispatch_query = new QueryWrapper($this->dispatch_db_conn);
	}
	
	function dispatch(&$transaction_obj)  // Return type is true/false on watch events, and Message objects for remote client messages.
	{									  // This function is pass-by-reference.  Therefore any changes we make to the 
										  // transaction, we will be modifying this action transaction and not a copy.
		$this->transaction_obj = $transaction_obj;
		if ($this->transaction_obj->hasNewMessages())
		{
			$this->message_obj = $this->transaction_obj->popNewMessage();
		}
		else if (!$this->transaction_obj->hasNewMessages() && $this->transaction_obj->hasPendingMessages())
		{
			$this->message_obj = $this->transaction_obj->popPendingMessage();
		}
		$command = $this->message_obj->getCommand();
		
		// NOTE:  PLACEMENT LOCATION CRITICAL.  THINK BEFORE YOU MOVE THIS "IF" CHECK AROUND!
		// Blindly accept a BYE message and ACK it.
		if ($command == "BYE") 
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ACK");
			return $this->transaction_obj->buildAndAddMessage($return_message);  // buildAndAddMessage() returns a message object.
			
		}
		// NOTE:  PLACEMENT LOCATION CRITICAL.  THINK BEFORE YOU MOVE THIS "IF" CHECK AROUND!
		// Need to check to see if we received an ACK to our 411 Session Expired Error message.
		else if ($this->message_obj->getCommand() == "ACK" && $this->transaction_obj->getPreviousMessageErrorCode() == "411" && ($this->message_obj->getReplyToCommand() == $this->transaction_obj->getPreviousMessageCommand()))
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("BYE");
			return $this->transaction_obj->buildAndAddMessage($return_message);  // buildAndAddMessage() returns a message object.
		}
		
		// Check to see if the transaction has expired
		if ($this->transaction_obj->hasExpired())
		{
			/*
			 * Client  ------------------------  Server
			 *         <-----------------------  ERROR (411 - Session Expired) 
			 * ACK     ----------------------->  
			 *         <-----------------------  BYE 
			 * ACK     ----------------------->  discard ack.  
			 */
			
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ERROR");
			$return_message->setReplyErrorCode("411");
			$return_message->setReplyNotes("Session Expired");
			echo "ERROR:  Dispatcher::dispatch() - Session Expired.\n";
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
	
		if ($command == "REGISTER")
		{
			return $this->receivedRegisterMemberServer();
		}
		else if ($command == "WATCHEVENT")
		{
			return $this->recordWatchEvent();
		}
		else if ($command == "UNREGISTER")
		{
			return $this->receivedUnregisterMemberServer();
		}
		else if ($command == "CHECKIN")
		{
			return $this->receivedMemberServerCheckin();
		}
		else if ($command == "UPDATE")
		{
			return $this->updateMemberServerValues();
		}
		else if ($command == "GETSHARES")
		{
			return $this->receivedGetShares();
		}
		else if ($command == "GETSHARE")
		{
			return $this->receivedGetShare();
		}
		else if ($command == "PRESENTSHARES")
		{
			return $this->receivedPresentShares();
		}
		else if ($command == "REQUESTSYNC")
		{
			return $this->receivedRequestSync();
		}
		else if ($command == "SYNC")
		{
			
		}
		else if ($command == "SYNCREFRESH")
		{
			
		}
		else if ($command == "QUEUED")
		{
			return $this->receivedPending();
		}
		else if ($command == "BYE")
		{
			return $this->receivedBye();
		}
		else if ($command == "ACK")
		{
			return $this->receivedAck();
		}
		else if ($command == "ERROR")
		{
			return $this->receivedError();
		}
		else
		{
			return (false);
		}
	}
	
	protected function receivedRegisterMemberServer()  // Completed on 12/12/2009;  Updated 2/17/2010
	{
		$clientid = $this->message_obj->getClientID();
		$public_ip_address_array = explode(":", stream_socket_get_name($this->message_obj->getSocket(), true));
		$public_ip_address =   trim($public_ip_address_array[0]); // Pub IP should not be sent by client.
																  // This can be used as a NAT determination tool.
		$ip_address = $this->message_obj->getArgumentValue("ADDRESS");  // This is the internal, possibly NATed, IP of the client.
		
		if ($this->checkPassword())
		{
			if (!$this->isClientRegistered($clientid))  // Only proceed if the clientid does not already exist in the syn_partners table.
			{
				$name = $this->message_obj->getArgumentValue("NAME");
				$bandwidthup = $this->message_obj->getArgumentValue("BANDWIDTHUP");
				$bandwidthdown = $this->message_obj->getArgumentValue("BANDWIDTHDOWN");
				$timezone_offset = $this->message_obj->getArgumentValue("TIMEZONE");
				$last_checkin = date("Y\-m\-d G:i:s");
				$afrs_version = $this->message_obj->getArgumentValue("AFRSVERSION");  
				$priority = $this->message_obj->getArgumentValue("PRIORITY");
				
				if ($public_ip_address != $ip_address)
				{
					echo "Client's IP has been NATed\n";
				}
				/* TODO:  Need to do a db select on the ip and pub ip to see if the new request's ips are already in the db.
				*		  This has to be done in the php code and not via the db so we can return a descriptive error to the client.
				*/
				if ($this->dispatch_query->runQuery("insert into tbl_sync_partners (clientid, date_added, ip_address, public_ip_address, fqdn, timezone_offset, status, last_checkin, afrs_version, bandwidth_up, bandwidth_down, priority) values($clientid, '$last_checkin', '$ip_address', '$public_ip_address', '$name', '$timezone_offset', 1, '$last_checkin', '$afrs_version', $bandwidthup, $bandwidthdown, '$priority')"))						 
				{
					echo "Registered " . $name . "(" . $ip_address . "/" . $public_ip_address . ") as a member sync server.\n";
					return $this->transaction_obj->buildAndAddMessage($this->buildReturnAck());
				}
				else
				{
					echo "ERROR:  (Dispatcher) Failure registering client " . $ip_address . "/" . $public_ip_address . "\n";
					$return_message = new Message($this->message_obj->getSocket());
					$return_message->setCommand("ERROR");
					$return_message->setReplyErrorCode("506");
					$return_message->setReplyNotes("Registration Failed.");
					return $this->transaction_obj->buildAndAddMessage($return_message);
				}
			}
			else
			{
				echo "ERROR: (Dispatcher) Failure registering client.  Client ID: " . $clientid . " already exists in sync_partners table.\n";
				$return_message = new Message($this->message_obj->getSocket());
				$return_message->setCommand("ERROR");
				$return_message->setReplyErrorCode("506");
				$return_message->setReplyNotes("Registration Failed - You are already registered with this server.");
				return $this->transaction_obj->buildAndAddMessage($return_message);
			}
		}
		else
		{
			echo "ERROR: (Dispatcher) Client with ID of: " . $clientid . " provided an incorrect membership password\n";
			echo "        Failed attempt was made from PUBLIC_ADDR: " . $public_ip_address . " PRIVATE_ADDR: " . $ip_address . "\n";
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ERROR");
			$return_message->setReplyErrorCode("401");
			$return_message->setReplyNotes("Unauthorized - Bad password,");
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
	}
	
	protected function recordWatchEvent()
	{
		// TODO  Need to find a faster way of getting the argument values.  Maybe passing the values back as an ordered array.
		$watch_id = $this->message_obj->getArgumentValue("WATCHID");
		$date = $this->message_obj->getArgumentValue("DATETIME");
		$file = $this->message_obj->getArgumentValue("PATH");
		$type = $this->message_obj->getArgumentValue("FILETYPE");
		$event = $this->message_obj->getArgumentValue("ACTION");
		$uid = $this->message_obj->getArgumentValue("UID");
		$uid_name = $this->message_obj->getArgumentValue("USER");
		$gid = $this->message_obj->getArgumentValue("GID");
		$gid_name = $this->message_obj->getArgumentValue("GROUP");
		$posix_permissions = $this->message_obj->getArgumentValue("POSIXPERMISSIONS");
		$size = $this->message_obj->getArgumentValue("SIZE");
		
		
		if ($this->dispatch_query->runQuery("insert into tbl_journal
											(watch_id, date, file, type, event, uid, uid_name, gid, gid_name, posix_permissions, size) 
											values(1, '$date', '$file', '$type', '$event', '$uid', '$uid_name', '$gid', '$gid_name', '$posix_permissions', '$size')"))
		{
			return (true);
		}
		else
		{
			return (false);
		}
	}
	
	protected function receivedUnregisterMemberServer()  // TODO:  Need to finish after all of the other commands have been completed.
	{
		if ($this->checkPassword())
		{
			$clientid = $this->message_obj->getArgumentValue("CLIENTID");
			
			if ($this->isClientRegistered($clientid))
			{
				// TODO Run all kinds of query shit to remove db records associated with the client's ID.
				
			}
			else
			{
				echo "ERROR: Dispatcher::receivedUnregister() - 400 - Member server with client ID of: " . $clientid . " does not exist.\n";
				$return_message = new Message($this->message_obj->getSocket());
				$return_message->setCommand("ERROR");
				$return_message->setReplyErrorCode("400");
				$return_message->setReplyNotes("Bad Request - You are not registered with this server.");
				return $this->transaction_obj->buildAndAddMessage($return_message);
			}
		}
		else
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ERROR");
			$return_message->setReplyErrorCode("401");
			$return_message->setReplyNotes("Unauthorized - Bad password,");
			echo "ERROR:  Dispatcher::receivedUnregister() - 401 - Bad Password.  Client provided a bad password when tring to unregister from this server.\n";
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
	}
	
	protected function receivedMemberServerCheckin()
	{
		$clientid = $this->message_obj->getClientID();
		echo "CHECKING CLIENT ID.  IT IS: " . $clientid . "\n";
		if ($this->checkPassword())
		{
			if ($this->isClientRegistered($clientid))
			{
				$this->dispatch_query->runQuery("select fqdn as name from tbl_sync_partners where clientid = '$clientid'");
				$result = $this->dispatch_query->getResultAssoc();
				$name = $result["name"];
				
				if ($this->dispatch_query->runQuery("update tbl_sync_partners set last_checkin = NOW() where clientid = '$clientid'"))
				{
					echo "Checkin attempt was successfull for " . $name . "\n";
					return $this->transaction_obj->buildAndAddMessage($this->buildReturnAck());
				}
				else
				{
					$return_message = new Message($this->message_obj->getSocket());
					$return_message->setCommand("ERROR");
					$return_message->setReplyErrorCode("500");
					$return_message->setReplyNotes("Internal Server Error - Failed to check you in.  Please try again.");
					echo "ERROR:  Dispatcher::receivedUpdateMemberServerCheckin() - Failed to checkin client: " . $clientid .  " (". $name . ").\n";
					return $this->transaction_obj->buildAndAddMessage($return_message);
				}
			}
			else
			{
				$return_message = new Message($this->message_obj->getSocket());
				$return_message->setCommand("ERROR");
				$return_message->setReplyErrorCode("401");
				$return_message->setReplyNotes("Unauthorized - You are not a registered client with this server.  Go away.");
				echo "ERROR:  Dispatcher::receivedUpdateMemberServerCheckin() - Can't update checkin time for client " . $clientid .  " since they are not a registered client with us.\n";
				return $this->transaction_obj->buildAndAddMessage($return_message);
			}
		}
		else
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ERROR");
			$return_message->setReplyErrorCode("401");
			$return_message->setReplyNotes("Unauthorized - Bad password specified.  Go away.");
			echo "ERROR:  Dispatcher::receivedUpdateMemberServerCheckin() - Can't update checkin time for client " . $clientid .  " bad password specified.\n";
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
	}
	
	protected function updateMemberServerValues()  // Completed 12/14/2009
	{
		$clientid = $this->message_obj->getClientID();
		if ($this->checkPassword($this->message_obj))
		{
			if ($this->isClientRegistered($clientid))
			{
				$this->dispatch_query->runQuery("select fqdn as name from tbl_sync_partners where clientid = '$clientid");
				$result = $this->dispatch_query->getResultAssoc();
				$name = $result["name"];
				
				$argument = $this->message_obj->getArgumentValue("PARAM");
				$argument_value = $this->message_obj->getArgumentValue("VALUE");
				if ($this->dispatch_query->runQuery("update tbl_sync_partners set $argument = '$argument_value' where clientid = '$clientid'"))
				{
					echo "Successfully updated parameter: " . $argument . " for " . $name . ".  New value is: " . $argument_value . "\n";
					return($this->buildReturnAck());
				}
				else
				{
					echo "ERROR: (Dispatcher) updateMemberServerValues()\n";
					return ("REJECTED, ERROR 15");
				}
			}
			else
			{
				echo "ERROR: (Dispatcher) updateMemberServerValues()\n";
				return ("REJECTED, ERROR 17");
			}
		}
		else
		{
			echo "Dispatcher::updateMemberServerValues - Wrong password specified.\n";
		}
	}
	
	protected function receivedGetShare()   // This method can be called by a remote server in response to a REQUESTSYNC command.
	{								// to determine the atrributes of the local share chosen to participate in syncs.
									// Completed 1/25/2010
		$args_values_assoc_array = null;
		
		$clientid = $this->message_obj->getClientID();
		if ($this->checkPassword($this->message_obj))  // Only proceed if the client provided the correct password.
		{
			if ($this->isClientRegistered($clientid))  // Make sure the client is registered with this server before going further.
			{
				/*$this->dispatch_query->runQuery("select fqdn as name from tbl_sync_partners where clientid = '$clientid'");
				$result = $this->dispatch_query->getResultAssoc();
				$name = $result["name"];*/
				
				// Now we need to retrieve the password we have on-file for the requesting side so that we can 
				// use it in our reponse (PRESENTSHARES) back to the requesting client.
				$this->dispatch_query->runQuery("select membership_password 
												 from tbl_sync_partners
												 where clientid = '$clientid");
				$result = $this->dispatch_query->getResultAssoc();
				$remote_password = $result["membership_password"];
				
				// Get a list of shares from this server to send to the client.
				$this->dispatch_query->runQuery("select share_name, size, available_size, active, permission, creation_date 
												 from tbl_shares 
												 where active = '1'");
				$result_array = $this->dispatch_query->getResultsAssoc();
				$result_count = $this->dispatch_query->getResultSize();
				//$count = 1;
				if ($result_count > 0)
				{
					//echo "I found " . $result_count . " shares for this server.\n";
					$return_message = new Message($this->message_obj->getSocket());
					$return_message->setCommand("PRESENTSHARES");
					$args_values_assoc_array[] = array("MEMBERSHIPPASSWORD" => $remote_password);
					
					foreach($result_array as $this_result_array)
					{	
						$args_values_assoc_array[] =  array("SHARENAME" => $this_result_array["share_name"],
													   "SIZE" => $this_result_array["size"],
													   "AVAILABLESTORAGE" => $this_result_array["size"],
													   "ACTIVE" => $this_result_array["active"],
													   "PERMISSIONS" => $this_result_array["permission"],
													   "CREATIONDATE" => $this_result_array["creation_date"]);
					}
					$return_message->setArgumentValues($args_values_assoc_array);
					
					return $this->transaction_obj->buildAndAddMessage($remote_message);
				}
				else  // TODO:  Need to use a better error return system.
				{
					echo "No shares are available on this server for client: " . $this->message_obj->getArgumentValue("VALUE") . "\n";
					return ("REJECTED, ERROR 14");  // This will be interprested by the client as "No shares available".
				}
			}
			else
			{	// TODO:  Need to use a better error return system.
				echo "ERROR: Client " . $name . " is not a registered member server.  Can't give it a list of sync shares\n";
				return ("REJECTED, ERROR 13");
			}
		}
		else
		{
			echo "ERROR:  Dispatcher::getShares() - Wrong password specified.\n";
		}
	}
	
	protected function receivedGetShares()  // This method should be called by the client before initiating a REQUESTSYNC.
	{
		$args_values_assoc_array = null;
		
		$clientid = $this->message_obj->getClientID();
		if ($this->checkPassword())  // Only proceed if the client provided the correct password.
		{
			if ($this->isClientRegistered($clientid))  // Make sure the client is registered with this server before going further.
			{	
				// Now we need to retrieve the password we have on-file for the requesting side so that we can 
				// use it in our reponse (PRESENTSHARES) back to the requesting client.
				$this->dispatch_query->runQuery("select membership_password 
												 from tbl_sync_partners
												 where clientid = '$clientid'");
				$result = $this->dispatch_query->getResultAssoc();
				$remote_password = $result["membership_password"];
				
				// Get a list of shares from this server to send to the client.
				$this->dispatch_query->runQuery("select share_name, size, available_size, active, permission, creation_date 
												 from tbl_shares 
												 where active = '1'");
				$result_array = $this->dispatch_query->getResultsAssoc();
				$result_count = $this->dispatch_query->getResultSize();

				if ($result_count > 0)
				{
					//echo "I found " . $result_count . " shares for this server.\n";
					$return_message = new Message($this->message_obj->getSocket());
					$return_message->setCommand("PRESENTSHARES");
					$args_values_assoc_array[] = array("MEMBERSHIPPASSWORD" => $remote_password);
					
					foreach($result_array as $this_result_array)
					{	
						$args_values_assoc_array[] =  array("SHARENAME" => $this_result_array["share_name"],
													   "SIZE" => $this_result_array["size"],
													   "AVAILABLESTORAGE" => $this_result_array["size"],
													   "ACTIVE" => $this_result_array["active"],
													   "PERMISSIONS" => $this_result_array["permission"],
													   "CREATIONDATE" => $this_result_array["creation_date"]);
					}
					$return_message->setArgumentValues($args_values_assoc_array);
					return $this->transaction_obj->buildAndAddMessage($return_message);
					
				}
				else  // TODO:  Need to use a better error return system.
				{
					echo "No shares are available on this server for client: " . $this->message_obj->getArgumentValue("VALUE") . "\n";
					return ("REJECTED, ERROR 14");  // This will be interprested by the client as "No shares available".
				}
			}
			else
			{	// TODO:  Need to use a better error return system.
				echo "ERROR: Client " . $name . " is not a registered member server.  Can't give it a list of sync shares\n";
				return ("REJECTED, ERROR 13");
			}
		}
		else
		{
			echo "ERROR:  Dispatcher::getShares() - Wrong password specified.\n";
		}
	}
	
	protected function receivedPresentShares()  // Completed on 1/25/2010
	{
		$clientid = $this->message_obj->getClientID();
		if ($this->isClientRegistered($clientid))  // Make sure the client is registered with this server before going further.
		{
			if ($this->checkPassword())
			{
				if ($this->message_obj->getSequenceNumber() > 0)  // Sequence number has to be greater than zero or else this message was spoofed.
				{
					// Get the shares that the remote side sent to us and store them in the db.
					$arguments_and_values_array = $this->message_obj->getCommandArgumentsValues();
					//var_dump($arguments_and_values_array);
					//array_shift($arguments_and_values_array);  // Pop off the first array element CLIENTID so that we can do even math.
					array_shift($arguments_and_values_array);  // Pop off the fist array element MEMBERSHIPPASSWORD so that we can do even math.
					
					// Split the array into a 2D array, one 1D array for each shared name returned by the remote end.
					$arguments_and_values_array = array_chunk($arguments_and_values_array, ($this->message_obj->getExpectedCommandArgSize() - 1));
					$last_updated = date("Y\-m\-d G:i:s"); // Now.
					
					foreach ($arguments_and_values_array as $this_args_and_vals_array)
					{
						$share_name = $this_args_and_vals_array[0][1];
						$size = $this_args_and_vals_array[1][1];
						$available_size = $this_args_and_vals_array[2][1];
						$active = $this_args_and_vals_array[3][1];
						$permission = $this_args_and_vals_array[4][1];
						$creation_date = $this_args_and_vals_array[5][1];
						
						// First we need to check to see if the shares already exist in our db listing for the client.  If they
						// do, then we perform a db update query.  If they do not exist in our db then we do a db insert.
						$this->dispatch_query->runQuery("select count(*) as record_count from tbl_partner_shares where share_name = '$share_name' and clientid = '$clientid'");
						$result = $this->dispatch_query->getResultAssoc();
						$record_count = $result["record_count"];
						
						if ($record_count == 1) // Perform an update query since the client shares already exist in our db or this is a reply to an initial REQUESTSYNC command.
						{
							// Check to see if this reply is part of a pending REQUESTSYNC command.
							if ($this->transaction_obj->hasPendingMessages())
							{
								$pending_message_object = $this->transaction_obj->popPendingMessage();
								if ($pending_message_object->getCommand() == "REQUESTSYNC")
								{
									return $this->transaction_obj->buildAndAddMessage($this->buildReturnAck());
								}
							}
							else
							{
								$this->dispatch_query->runQuery("update tbl_partner_shares set 
																 share_name = '$share_name', 
																 size = $size, 
																 available_size = $available_size,
																 active = $active,
																 permission = '$permission',
																 creation_date = '$creation_date',
																 last_updated = '$last_updated'
																 where clientid = '$clientid'");
							}
						}
						else if ($record_count == 0)  // Perform an insert query since the client shares do not already exist in our db.
						{
							$this->dispatch_query->runQuery("insert into tbl_partner_shares
														 (clientid, share_name, size, available_size, active, permission, creation_date, last_updated)
													 	values('$clientid', 
																'$share_name',
																$size,
																$available_size,
																$active,
																'$permission',
																'$creation_date',
																'$last_updated')");
						}
					}
					return($this->buildReturnAck());
				}
				else  // TODO: Need to implement the Throw exception stuff here for errors.
				{
					echo "ERROR:  Dispatcher::receivedPresentShares() - Message sequence number is not > 0.  Potentially spoofed message by unauthorized client/server.\n";
				}
			}
			else
			{
				echo "ERROR:  Incorrect password\n";
			}
		}
		else  // TODO: Need to implement the Throw exception stuff here for errors.
		{
			echo "ERROR:  Dispatcher:: receivedPresentShares() - Client is not registered.\n";
		}
	}
	
	protected function receivedRequestSync()  // TODO:  Need to implement logic to update parameters if the sync point 
	{										  //        already exists in the db.  If so update the info from remote.
		$clientid = $this->message_obj->getClientID();
		
		if ($this->checkPassword($this->message_obj))
		{	
			if ($this->isClientRegistered($clientid))  // Make sure the client is registered with this server before going further.
			{
				if ($this->transaction_obj->hasPendingMessages())
				{
					// First we need to get the message object for the REQUESTYSYNC command.
					$pending_message_object = $this->message_obj;  // This is set at the top of this file.  LOOK!!
					$local_sharename = $pending_message_object->getArgumentValue("SHARENAME");
					$mode = $pending_message_object->getArgumentValue("MODE");
					
					$local_mode_map = array("DUPLEX" => "DUPLEX", "PUSH" => "PULL", "PULL" => "PUSH");
					$local_mode = $local_mode_map[$mode];  // Transform the remote mode into the corresponding local mode.
														   // Doing it this way saves from the if statements that we would 
														   // have to use.
					
					$present_share_object = $this->transaction_obj->searchForCommand("PRESENTSHARES");
					
					// Being a little paranoid on making sure the info get returned is correct.
					if (is_object($present_share_object) && $present_share_object->getComand() == "PRESENTSHARES")
					{
						$remote_sharename = $present_share_object->getArgumentValue("SHARENAME");
						$remote_size = $present_share_object->getArgumentValue("SIZE");
						$remote_available_storage = $present_share_object->getArgumentValue("AVAILABLESTORAGE");
						$remote_permission = $present_share_object->getArgumentValue("PERMISSIONS");
						$remote_is_active = $present_share_object->getArgumentValue("ACTIVE");
						
						// Only proceed if the remote side's share is active.  If it's not then it request to sync with us 
						// for this share is irrelavent.
						if ($remote_is_active == '1')
						{
							// Get all of the relevant requested info from the db.
							$this->dispatch_query->runQuery("select share_name, size, available_size, permission
														 from tbl_shares 
														 where active = '1' and share_name = '$local_sharename'");	
							
							if ($result = $this->dispatch_query->getResultAssoc())
							{
								$local_size = $result["size"];
								$local_available_size = $result["available_size"];
								$local_permision = $result["permission"];
								
								// Make sure the local and remote permissions jive.
								if (($mode == "PULL" && $remote_permission == "write" && $local_permision == "read") || ($mode == "PUSH" && $remote_permission == "read" && $local_permision == "write") || ($mode == "DUPLEX" && $remote_permission == "read/write" && $local_permision == "read/write"))
								{
									// Now that the permissions and sync mode's jive, make sure the sync sizes jive.
									if (($mode == "PULL" && $remote_available_storage > ($remote_size + $local_size)) || ($mode == "PUSH" && $local_available_size > ($local_size + $remote_size)) || ($mode == "DUPLEX" && (($local_available_size > ($local_size + $remote_size)) || $remote_available_storage > ($remote_size + $local_size))))
									{
										if($this->dispatch_query->runQuery("insert into tbl_sync_partner_watches 
																	 (sync_partner_id, fk_share_id, mode, active) 
																	 select '$clientid', tbl_shares.id, '$local_mode', '1' 
																	 	from tbl_shares where tbl_shares.share_name = '$local_sharename'") != false)
										{
											return $this->transaction_obj->buildAndAddMessage($this->buildReturnAck(), $this->message_obj);  // $this->message_obj is the queued REQUESTSYNC object.
										}
										else
										{
											$return_message = new Message($this->message_obj->getSocket());
											$return_message->setCommand("ERROR");
											$return_message->setReplyErrorCode("500");
											$return_message->setReplyNotes("Internal Server Error - Failed to add the requested sync point to the remote database.\n");
											echo "ERROR:  Dispatcher:: receivedRequestSync() - 500 - Internal Server Error - Failed to add the requested sync point to the local database.\n";
											return $this->transaction_obj->buildAndAddMessage($return_message);
										}
									}
								}
								else
								{
									$return_message = new Message($this->message_obj->getSocket());
									$return_message->setCommand("ERROR");
									$return_message->setReplyErrorCode("409");
									$return_message->setReplyNotes("Conflict - Your share permissions conflict with our share's local settings/attributes.");
									echo "ERROR:  Dispatcher::receivedRequestSync() - Conflict - Received parameters conflict with local settings/attributes.\n";
									return $this->transaction_obj->buildAndAddMessage($return_message);
								}
							}
						}
						else
						{
							$return_message = new Message($this->message_obj->getSocket());
							$return_message->setCommand("ERROR");
							$return_message->setReplyErrorCode("480");
							$return_message->setReplyNotes("Temporarily Unavailable - The share on your side for this sync request is not active at this time.  Please fix and try again.");
							echo "ERROR:  Dispatcher::receivedRequestSync() - 480 - Temporarily Unavailable - The share on the remote side is not active for the sync request they presented to us.\n";
							return $this->transaction_obj->buildAndAddMessage($return_message);
						}
					}
					else
					{
						$return_message = new Message($this->message_obj->getSocket());
						$return_message->setCommand("ERROR");
						$return_message->setReplyErrorCode("500");
						$return_message->setReplyNotes("Internal Server Error - Fatal Server Error.  If this continues, contact AFRS creator to fix!.");
						echo "ERROR:  Dispatcher::receivedRequestSync() - 500 - Internal Server Error - Fatal Server Error.  If this continues, contact AFRS creator to fix!. \n";
					}
				}
				else // Only run if we don't have any pending messages.
				{
					// Now we return the command QUEUED since we will have to eventually generate the 
					// GETSHARE for the sharename specified.  We need info out the remote side's SHARE before
					// we can fulfill this requst.  Therefore, request pending...
					$return_message = new Message($this->message_obj->getSocket());
					$return_message->setCommand("QUEUED");
					$this->transaction_obj->buildAndAddMessage($return_message);
					return $this->transaction_obj->buildAndAddMessage($return_message);
				}	
			}
			else
			{
				$return_message = new Message($this->message_obj->getSocket());
				$return_message->setCommand("ERROR");
				$return_message->setReplyErrorCode("407");
				$return_message->setReplyNotes("Authentication Required - You are not a registered client with this server.  Go away.");
				echo "ERROR: Dispatcher::receivedRequestSync() - 407 - Authentication Required - The remote client is not a registered client of ours so they can't make requests like these.\n";
				return $this->transaction_obj->buildAndAddMessage($return_message);
			}
		}
		else
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ERROR");
			$return_message->setReplyErrorCode("407");
			$return_message->setReplyNotes("Authentication Required - The password you specified for this server is not correct.  Go away.");
			echo "ERROR: Dispatcher::receivedRequestSync() - 407 - Authentication Required - The remote client provided an incorrect password for this server.\n";
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
		
	}
	
	protected function receivedPending()
	{
		// Mark the message this received PENDING command is for, as PENDING.
		$this->transaction_obj->markMessagePending($this->transaction_obj->getMessageOfSequenceNumber($this->message_obj->getReplyToSequenceNumber()));
		
		// After we have marked the appropriate message as PENDING, reply with an ACK.
		$return_message = new Message($this->message_obj->getSocket());
		return $this->transaction_obj->buildAndAddMessage($this->buildReturnAck());
	}
	
	protected function sendGetShare($share_name_on_remote)
	{
		$return_message = new Message($this->message_obj->getSocket());
		$return_message->setCommand("GETSHARE");
		$return_message->setArgumentValue("SHARENAME", array(0 => $share_name_on_remote));
		return $return_message;
	}
	
	protected function sendGetShares($remote_client_id)
	{
		
	}
	
	protected function sendPresentShares($shares_array)
	{
		$shares_message = new Message($this->message_obj->getSocket());  // Create a new message to send to client referencing the original socket to reply to.
		$shares_message->setCommand("PRESENTSHARES");  // Set the message command.
		$serialized_shares = serialize($shares_array);
		//$sid = getSID();  // Get this server's securityID (SID).  The SID is used as the CLIENT_ID to remote servers (clients).
		$shares_message->setArgumentValues(array('SHARES' => $serialized_shares));  // Set the sharenames and the sizes.
		
		$shares_message->saveXML();  // Create the actual XML string to send to the client.
		return $shares_message; // Return the reply message to afrsd to send the response.
	}
	
	protected function receivedEndTransaction()
	{
		// We will blindly honor an BYE command.  I.e. we will not check anything, we will just ack it and 
		// afrsd parent will tear-down/destroy the transaction tied to this message when we return from this method.
		return($this->buildReturnAck());
	}
	
	protected function receivedAck()
	{
		$response_to_command = $this->message_obj->getReplyToCommand();
		
		if ($response_to_command == "REGISTER" || $response_to_command == "CHECKIN")
		{
			// The register command is complete, and completes this transaction.  Therefore, end the transaction with a BYE.
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("BYE");
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
		elseif ($response_to_command == "PRESENTSHARES")
		{
			if (!$this->transaction_obj->hasPendingMessages())
			{
				/*
				 * Client  ------------------------  Server
				 * GETSHARES --------------------->
				 *         <-----------------------  PRESENTSHARES
				 * ACK     ----------------------->
				 *         <-----------------------  BYE 
				 * ACK     ----------------------->  discard ack.  
				 */
				
				$return_message = new Message($this->message_obj->getSocket());
				$return_message->setCommand("BYE");
				return $this->transaction_obj->buildAndAddMessage($return_message);
			}
		}
		elseif ($response_to_command == "QUEUED")
		{
			// Now we need to determine where we left off and do our shit.  More in-depth description to come.
			
			if ($this->transaction_obj->getPendingMessageCount() == 1)  // We are only working with transactions that have one pending message (for now).
			{
				$pending_message_object = $this->transaction_obj->popPendingMessage();
				$pending_message_command = $pending_message_object->getCommand();
				
				if ($pending_message_command == "REQUESTSYNC")
				{
					// This will build and return the message object with the command of GETSHARE with the appropriate share name.
					return $this->transaction_obj->buildAndAddMessage($this->sendGetShare($pending_message_object->getArgumentValue("SHARENAME")));
				}
			}
			
		}
		else  // Catch-all
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("BYE");
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
	}
	
	protected function receivedError()
	{
		if ($this->message_obj->getErrorCode() == "411")
		{
			$return_message = new Message($this->message_obj->getSocket());
			$return_message->setCommand("ACK");
			return $this->transaction_obj->buildAndAddMessage($return_message);
		}
		
	}
	
	protected function isClientRegistered($clientid)
	{
		echo "CLIENTID PASSED IS: " . $clientid . "\n";
		$this->dispatch_query->runQuery("select count(clientid) as count from tbl_sync_partners where clientid = '$clientid'");
		$result = $this->dispatch_query->getResultAssoc();
		$result_count = $result["count"];
		
		if ($result_count == 1)
		{
			return (true);
		}
		else
		{
			return (false);
		}
	}
	
	protected function checkPassword()
	{
		$this->dispatch_query->runQuery("select value from tbl_registry where name = 'membership_password'");
		$result = $this->dispatch_query->getResultAssoc();
		$local_membership_password = trim($result["value"]);
		if ($this->message_obj->getArgumentValue("MEMBERSHIPPASSWORD") == $local_membership_password)
		{
			return(true);
		}
		else
		{
			return(false);
		}	
	}
	
	protected function buildReturnAck()
	{
		$return_message = new Message($this->message_obj->getSocket());
		$return_message->setCommand("ACK");
		return($return_message);
	}
}
?>