<?php

Class Log
{
	function addEntry($error_code, $message)
	{
		
	}
}
?>