<?php
/*
 * This class is simply used to keep track of an on-going conversation or to create a new one.
 * It also servers to determine if a response is valid to a previously issued command.  If not
 * return an error to the client.  
 * 
 * A Transaction holds an array of message objects.  When a message object is received, it is 
 * processed to determine if it is in sequence and is a valid command/response.  If so it returns
 * true to the AFRS Deamon so that it can dispatch the message accordingly.
 * 
 * TODO:  Actually the only thing this class needs to determine if it's valid is its transaction_id, 
 * 		  sequence number and most importantly, command.  In the future we may be able to reduce 
 * 		  processing load by only passing these values to this class.
 */

require_once("includes/functions.php");
require_once("includes/system/Message.php");
require_once("includes/system/Dispatcher.php");

Class Transaction
{
	private		$transaction_id = null,
				$transaction_message_array = null,  // An array of message objects contain the history of a conversation/transaction.
				$trans_db_conn = null,
				$trans_query = null,
				$global_session_expires = null,
				$last_seq_number = null,
				$has_new_messages = false,
				$pending_messages = null;  // An array of index locations of messages that are pending responses.  For instance, REQUESTSYNC would initially be pending since it generates a GETSHARE command from the receiving side.
	
	function __construct($message_object)
	{
		if (is_object($message_object))
		{
			require("conf/afrs_config.php");  // Variables are out of scope if outside a function and outside a class declaration in Classes.			
			$this->trans_db_conn = new DbConnectionWrapper($dbtype, $dbhost, $dbname, $dbuser, $dbpassword);  // TODO  Need to figure out why I can't use the vars from the config include.
			$this->trans_query = new QueryWrapper($this->trans_db_conn);
			
			$this->trans_query->runQuery("select value from tbl_registry where name = 'session_expires'");
			$result = $this->trans_query->getResultAssoc();
			$this->global_session_expires = $result["value"];
		
			$transaction_id = $message_object->getTransactionID();
			$sequence_number = $message_object->getSequenceNumber();
			
			if ($transaction_id == null && $sequence_number == null)  // A new transaction started by us, not a remote client.
			{
				// Need to create a new transaciton ID.
				$this->transaction_id = hash('md5', microtime());
				echo "Created a new transaction with an id of: " . $this->transaction_id . "\n";
				$message_object->setTransactionID($this->transaction_id);
				$message_object->setSequenceNumber(1);
				$this->last_seq_number = 1;
				$this->transaction_message_array[0] = $message_object;
				$this->is_paused = false;  // This transaction is not in a paused state.
				$this->has_new_messages = true;
			}
			else if ($transaction_id !=null && $sequence_number == 1)  // A new transaction started by remote end.
			{
				$this->transaction_id = $transaction_id;  // Get the transaction id created by the remote client.
				echo "Created a new transaction (initiated by remote) with an id of: " . $this->transaction_id . "\n";
				$this->last_seq_number = $sequence_number;
				$this->transaction_message_array[] = $message_object;
				$this->has_new_messages = true;
			}
			else
			{
				echo "ERROR:  Transaction::__construct().  Invalid call to constructor.\n";
			}
		}
		else
		{
			// TODO: Report error.
		}
	}
	
	function __destruct()
	{
		// TODO:	Need to do more check, such as destroy any processes associated with this
		//			transaction, etc. i.e.  Destroy any rsync processes so they don't become zombies.
		echo "## Transaction destructor was called. Nothing really done though. ##\n";
	}
	
	function addMessage($message_object)  // This should ONLY called when adding messages to the transaction from remote clients.
	{	
		echo "Last sequence number is: " . $this->last_seq_number . "\n";
		
		$message_command = $message_object->getCommand();
		$seq_num = $message_object->getSequenceNumber();

		// TODO:  Need to add logic to determine if the message being process is a valid response to the previous message.
		//		  If so then return true to the deamon so it can dispatch the message.
		if ($seq_num == ($this->last_seq_number + 1)) // Make sure that the received message is in sequence.
		{											  // This check may not be needed since we define the sequence number for this 
													  // message object as the first operation in this method.
			$this->transaction_message_array[] = $message_object;  // Store the message for this transaction.
			$this->last_seq_number = $seq_num;
			return (true);
		}
		else if ($seq_num == null)  // (Received from local).  Since the Transaction class sets the sequence number, locally created message don't have sequence numbers yet and therefore testing for null.
		{
			$message_object->setSequenceNumber(($this->last_seq_number + 1));
			$this->transaction_message_array[] = $message_object;
			$this->last_seq_number++;
			return (true);
		}
		else // Return the error in the form of a Message object so we can send the error back to the client.
		{
			$return_message = new Message($message_object->getSocket());
			$return_message->setTransactionID($message_transaction_id);
			$return_message->setSequenceNumber($seq_num + 1);  // Even though this message is out of sequence, use the remote ends sequence numbering so it can process the message as an error.
			$return_message->setCommand("ERROR");
			$return_message->setReplyToCommand($message_command);
			$return_message->setReplyToSequenceNumber($seq_num);
			$return_message->setReplyErrorCode("412");
			$return_message->setReplyNotes("Out of Sequence.  Expecting " . ($this->last_seq_number + 1) . ", got " . $seq_num . "\n");
			$return_message->buildTransmitMessage();
			echo "ERROR: Transaction::addMessage().  Message received is out of sequence.  Expecting " . ($this->last_seq_number + 1) . ", got " . $seq_num . "\n";
			return ($return_message);
		}
		$this->has_new_messages = true;
	}
	
	function buildAndAddMessage($message_object)  // This is usually called as the last method when building messages.
	{
		$num_args = func_num_args();  // If 1, then build the reply message in lockstop.
									  // If 2, build the reply message in accordance to the second arg (message_object.
									  // 2 usually applies to replying to messages that have been queued.
		
		echo "Last sequence number is: " . $this->last_seq_number . "\n";
		if ($num_args == 1)
		{	
			$message_object->setTransactionID($this->transaction_id);
			$message_command = $message_object->getCommand();
			$last_message_object = $this->getNewestMessage();
			$last_message_command = $last_message_object->getCommand();
			$message_object->setReplyToCommand($last_message_command);
			$message_object->setReplyToSequenceNumber($this->last_seq_number);
			$message_object->setSequenceNumber($this->last_seq_number + 1);  // Set the message object seq_num 
																			 // based off of the last message's
																			 // seq_number.
			$message_object->buildTransmitMessage();  // This is an important step here.
			$seq_num = $message_object->getSequenceNumber();
			
			if ($message_command == "QUEUED")
			{
				$this->pending_messages[] = $this->getIndex($last_message_object); 
			}
	
			// TODO:  Need to add logic to determine if the message being process is a valid response to the previous message.
			//		  If so then return true to the deamon so it can dispatch the message.
			if ($seq_num == ($this->last_seq_number + 1)) // Make sure that the received message is in sequence.
			{											  // This check may not be needed since we define the sequence number for this 
														  // message object as the first operation in this method.
				$this->transaction_message_array[] = $message_object;  // Store the message for this transaction.
				$this->last_seq_number = $seq_num;
				return ($message_object);
			}
			else if ($seq_num == null)  // (Received from local).  Since the Transaction class sets the sequence number, locally created message don't have sequence numbers yet and therefore testing for null.
			{
				$message_object->setSequenceNumber(($this->last_seq_number + 1));
				$this->transaction_message_array[] = $message_object;
				$this->last_seq_number++;
				return ($message_object);
			}
			else
			{
				return (false);
			}
		}
		else if ($num_args == 2)  // Usually if we are replying to a command that was previously queued.
		{
			$message_object = func_get_arg(1);
			$queued_message_object = func_get_arg(2);
			
			$message_object->setTransactionID($this->transaction_id);
			$message_command = $message_object->getCommand();
			$last_message_object = $this->getNewestMessage();
			$queued_message_command = $queued_message_object->getCommand();
			$message_object->setReplyToCommand($queued_message_command);
			$message_object->setReplyToSequenceNumber($this->last_seq_number);
			$message_object->setSequenceNumber($this->last_seq_number + 1);  // Set the message object seq_num 
																			 // based off of the last message's
																			 // seq_number.
			$message_object->buildTransmitMessage();  // This is an important step here.
			$seq_num = $message_object->getSequenceNumber();
			return $message_object;
		}
	}
	
	function getIndex($message_object)  // NOTE:  The index location of the message is not the same number as the message's sequence number.  Just an FYI.
	{
		$index = null;
		$seq_num = $message_object->getSequenceNumber();
		$transaction_size = sizeof($this->transaction_message_array);
		for ($i = 0; $i < sizeof($transaction_size); $i++)
		{
			$loop_message_obj = $this->transaction_message_array[$i];
			// Maybe in the future we should also check to see if the message commands match.
			if ($loop_message_obj->getSequenceNumber() == $seq_num)
			{
				$index = $i;
				break;
			}
		}
		return $index;
	}
	
	function getLastSequenceNumber()
	{
		return $this->last_seq_number;
	}
	
	function getNewestMessage()
	{
		return $this->transaction_message_array[(sizeof($this->transaction_message_array)-1)];
	}
	
	function getNewestMessageCommand()
	{
		$newest_message_object = $this->getNewestMessage();
		return $newest_message_object->getCommand();
	}
	
	function getPendingMessageCount()
	{
		return sizeof($this->pending_messages);
	}
	
	function getPreviousMessage()
	{
		return $this->transaction_message_array[(sizeof($this->transaction_message_array)-2)];
	}
	
	function getPreviousMessageCommand()
	{
		$newest_message_object = $this->getPreviousMessage();
		return $newest_message_object->getCommand();
	}
	
	function getPrevioustMessageErrorCode()
	{
		$newest_message_object = $this->getPreviousMessage();
		return $newest_message_object->getErrorCode();
	}
	
	function getMessageAtLocation($location_index)
	{
		return $this->transaction_message_array[$location_index];
	}
	
	function getMessageOfSequenceNumber($sequence_number)
	{
		foreach ($this->transaction_message_array as $this_message_object)
		{
			if ($this_message_object->getSequenceNumber() == $sequence_number)
			{
				return $this_message_object;
			}
		}
	}
	
	private function getNewestMessageSeqNumber()  // Returns the sequence number of the newest message for this transaction.
	{
		return $this->getIndex($this->getNewestMessage());
	}
	
	function getSize()
	{
		return (sizeof($this->transaction_message_array));
	}
	
	function getTransactionID()
	{
		return $this->transaction_id;
	}
	
	function hasNewMessages()  // Used to determine if this transaction has any new messages to process.
	{
		return $this->has_new_messages;
	}
	
	function hasPendingMessages()
	{
		if (sizeof($this->pending_messages) > 0)
		{
			return (true);
		}
		else
		{
			return (false);
		}
	}
	
	function markMessagePending($message_object)
	{
		$this->pending_messages[] = $this->getIndex($message_object);
	}
	
	function popNewMessage()  // Returns the latest new message object that has not been processed yet.
	{
		if ($this->has_new_messages)  // Double check to see if we are beeing call in a valid way.
		{
			echo "Popping message from transaction\n";
			$this->has_new_messages = false;  // We popped the last new message so indicate that we have no new messages.
			return $this->transaction_message_array[sizeof($this->transaction_message_array) - 1];  // Account for index locations starting at 0 and not 1.
		}
		else
		{
			return false;
		}
	}
	
	function popPendingMessage() // Gets the latest pending message for this transaction.
	{
		return $this->transaction_message_array[$this->pending_messages[(sizeof($this->pending_messages) - 1)]];
	}
	
	function hasExpired()  // IMPORTANT!  Checking to see if a session expired is usually called by the Dispatcher class.
	{
		// TODO:  Hardcoded this to always return false for testing purposes.  Fix when used in production.
		
		//echo "Transaction message array size is: " . (sizeof($this->transaction_message_array) - 1) . "\n";
		//var_dump($this->transaction_message_array);
		$last_message_object = $this->transaction_message_array[(sizeof($this->transaction_message_array) - 1)];
		$last_message_command = $last_message_object->getCommand();
		
		/*if (($last_message_object->getTimeStamp() + $this->global_session_expires) < time())  // Max time has passed from the last received message to this method call.
		{
			return (true);
		}
		else
		{
			return (false);
		}*/
		return (false);
	}
	
	function searchForCommand($search_command)  // Returns the message object that contains the searched command.
	{
		foreach ($this->transaction_message_array as $this_message_object)
		{
			if ($this_message_object->getCommand() == $search_command)
			{
				return $this_message_object;
			}
			else
			{
				return false;
			}
		}
	}
	
}
?>