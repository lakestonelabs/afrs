<?php

require_once("includes/system/Message.php");

Class StreamSocketServer
{
	protected	$server_socket,
				$client_socket,
				$socket_result,
				$connection_count = null,
				$max_connections = null,
				$input_buffer = null,
				$master = null,  
				$clients_info = array(),
				$read = null,
				$mod_fd = null,
				$client_data_buffer = array(array()),  // 2d array that holds the client sockets and their data.
												   // [1][0] => client 1's socket. ([0][0] is always the server socket.)
												   // [1][1] => client 1's data.  The client data element is appended to 
												   // itself until a full conversation has been completed.  Then the 
												   // complete conversation is processed.
				$client_conn_manager = null;
				
	private		$sleep_interval = 100000;  // How long the server waits in milliseconds between checking for new connections.
										   // TODO  The sleep_interval should be stored and read from the db.
	
	// Returns type ConnectionManager
	function __construct($address, $port, $max_connections)
	{	
		// create a stream socket
		$this->server_socket = stream_socket_server("tcp://$address:$port", $errno, $errstr);
		$this->max_connections = $max_connections;
		$this->connection_count = 0;
		
		if ($this->server_socket != false)
		{
			$this->master[] = $this->server_socket;  // The server socket is always the first elemet in the 2d array.
			$this->read = $this->master;
		}
		else if ($this->server_socket === false)
		{
			echo "Error in server socket: " . $errstr . ":" . $errno . "\n";
			exit(1);
		}
	}
	
	function listen()
	{
		// Some of the below code was used from various users on the php doco website for the stream_socket_server page.
		$this->read = $this->master;
		
		// Before you pull you hair out trying to understand stream_select, read the socket_select.  
		// Pay close attention that both socket and stream select functions will modify the contents 
		// of the array on exit.  This will explain how $this->read[0] isn't always the server socket.
		$this->mod_fd = stream_select($this->read, $_w = NULL, $_e = NULL, 0, $this->sleep_interval);  // Block for 0sec + 200000 usec (.2sec).

		if ($this->mod_fd === false) 
		{
			echo "Could not read stream arrays.  Exiting listening loop.\n";
            return(false);
        }
        
        // Loop through and take care of the open streams.
        for ($i = 0; $i < $this->mod_fd; $i++)
        {
	        if ($this->read[$i] === $this->server_socket) 
	        {
                $this->client_socket = stream_socket_accept($this->server_socket) or die("Could not set up socket listener\n");
                // Below is the "master" server section.
                if ($this->connection_count < $this->max_connections)
                {	
                	// Greet the client.
	                fwrite($this->client_socket, "AFRS ver. 0.1alpha (Advanced File Replication Service)\n");
	                $this->registerClient($this->client_socket);  // Register the new client so we can start passing data between client & server.
                }
                else
                {
                	// Tell the client to go away.
                	fwrite($this->client_socket, "AFRS ver. 0.1alpha (Advanced File Replication Service)\nNo more connections accepted at this time.\n");
                	fclose($this->client_socket);
                }
            } 
            else
            {
            	// Below is the communication with the client after the master has connected to the client 
            	$this->client_socket = $this->read[$i];
            	$sock_data = null;
            	$read_size = 0;
            	
				$socket_info = stream_get_meta_data($this->client_socket);
				$unread_data_size = $socket_info["unread_bytes"];  // Dynamically get the size of client data 
																   // to send to fread();
				if ($unread_data_size >= 1024 || $unread_data_size === 0)
				{
					$read_size = 1024;  // 1024 was chosen so it does not block too long waiting for data 
										// and therefore give better program interaction response time.
				}
				else
				{
					$read_size = $unread_data_size;  // If we don't do this when the unread_bytes < 1024, then fread() 
													 // will block until it times-out or until it receives more data 
													 // until the buffer becomes 1024 again.  Therefore we need to 
													 // dynamically set it.
				}
				
				$sock_data = fread($this->client_socket, $read_size);
				if (strlen($sock_data) === 0) // Entire client connection closed.
				{ 
					if (!$this->unregisterClient($this->client_socket))  // First unregister the client from the AFRS server..
					{
						echo "ERROR trying to unregister client from the Connection Manager\n";
					}
				}
				else if ($sock_data === false) 
				{
					echo "Something bad happened while reading the client input.\n";
					$this->unregisterClient($this->client_socket);
					
				} 
				else
				{
					// Read data from each client.
					$key = array_search($this->client_socket, $this->master, true);  // Find the array position for the client.
					if ($this->client_data_buffer[$key][0] === $this->client_socket)  // Don't just match on name(text), match also on type (===),
					{
						$this->client_data_buffer[$key][1] .= $sock_data;  // Append the client data for that socket.
					}
				}
            }
        } // End of for loop.
	    return(true);
	}  // End of listen() method
	
	protected function registerClient($client_socket)
	{
     		$client_info = stream_socket_get_name($client_socket, true);
     		echo "Client connection initiated from " . $client_info . "\n";
     		$this->connection_count++;
     		$this->master[] = $client_socket;
			$this->client_data_buffer[][0] = $client_socket;  // Append the client socket to the rest of the client data array.
			return(true);
	}
	
	protected function unregisterClient($client_socket)  //  Accepts type socket.  Returns type bool.
	{
		//echo "Unregistering client: " . $client_socket . "\n";
		$key_to_del = array_search($client_socket, $this->master, true);  // Find the array position for the client.
		$client_info = stream_socket_get_name($client_socket, true);
		fclose($this->master[$key_to_del]);  // Must do this on the array not just the socket since the array is what a record keeper for all connections.
		unset($this->master[$key_to_del]);  // Must do this on the array not just the socket since the array is what a record keeper for all connections.
		unset($this->client_data_buffer[$key_to_del][0]);  // Unset the socket info.
		unset($this->client_data_buffer[$key_to_del][1]);  // Unset the data for that socket.
		$this->connection_count--;
		echo "Client connection closed from " . $client_info . "\n" . "----------------------------------------------------\n";
		return(true);
	}
	
	function getClientData()  // Returns an array of Message objects.
	{
		$clients_messages = array();
		$count = 0;
		foreach($this->client_data_buffer as $this_client_data)
		{
			if (preg_match('/\n\n/', $this_client_data[1]))  // Determine if a complete client message has been read. Denoted by a double return.
			{
				echo "Received two line returns!\n";
				// All messages are handled for a client before proceeding to the next client.
				$end = strrpos($this_client_data[1], "\n\n");  // Find the last occurance of a double-line return.  "a" in "abcde" is 0.
				$sub_string = substr($this_client_data[1], 0, $end);  // Get everything up to the last occurance of a line return.
				$sub_messages = preg_split('/\n\n/', $sub_string);  // Many messages can be in one client data string.  This is usually true for afrs-watcher events.
				foreach ($sub_messages as $this_sub_message)  // Many messages can be in one client data string.  This is usually true for afrs-watcher events.
				{
					if (strlen($this_sub_message) > 0)  // Don't create new message objects for the last element in $sub_messages which is always \n\
					{
						try
						{
							//echo "$this_sub_message";
							$client_message = new Message($this_client_data[0], $this_sub_message);  // origin_location can be either internal, or external.
							echo "New message received on: " . time() . "\n";
							$clients_messages[] = $client_message;
						}
						catch (Exception $e)
						{
							// TODO Need to figure out how we are going to send an error response back to
							// the client since all messages are xml-based now.
							// ANSWER (12/12/2009):  Build a Message object here, setting all of the XML error message
							// variables, then send it to the local sendToClient() method.
							
							// Send exception error message to client.
							//$this->sendToClient($this_client_data[0], $e->getMessage(), "internal");
							echo $e . "\n";
							return (false);
						}
					}
				}
				$key = array_search($this_client_data[0], $this->master, true);  // Find the position for a certain socket in the master array.
				if (($end + 2) < strlen($this_client_data[1]))  // We have some leftover data from a previously unfinished conversation.
				{
					$leftovers = substr($this_client_data[1], ($end + 2));  // +2 is so we don't reprocess the \n\n from the prior message.
					$this->client_data_buffer[$key][1] = $leftovers;  // Get the leftovers and store so
																	  // the rest of the conversatioin can be completed
																	  // at the next pass of getting remote client data.
				}
				else
				{
					$this->client_data_buffer[$key][1] = null;  // Zero out the client data buffer since the current data transaction has completed.
				}
															// We can use the same key index for both the master and client_data_buffer since 
															// we modify both master and client_data_buffer when any operation has occured and therefore
															// their indexes stay the same between both.
			}
			$count++;
		}
		return $clients_messages;
	}
	
	function sendToClient($message_object)
	{
		if (is_object($message_object))
		{
			$message = $message_object->getRawMessage();  // Get the XML string to send.
			$message = $message . "\n\n"; // Make sure to append two line returns so the remote end knows this is a complete conversation.
			if (is_resource($message_object->getSocket()))  // Determine if this message was from remote or internal.  If from internal then  
			{												// we need to transform the ip:port info stored as the socket into an actual socket.
				fwrite($message_object->getSocket(), $message);
			}
			else  // Create an actual socket from the ip:port info stored in the socket variable of the message.
			{
				// TODO:  Need to do some regex. stuff to determine if the ip:port is in a correct format.
				// TODO:  Need to find a way to create sockets to remote ends and not have to block for the 
				//        timeout period specified in the below parameter (2 seconds) for createing a sockt.  Would be nice 
				$socket = stream_socket_client("tcp://".$message_object->getSocket(), $errno, $errstr, 5); // We only wait 5 seconds for the remote side to resond.
			}
		}
		else
		{
			echo "StreamSocketServer::sendToClient : method paramater must be an object.\n";
		}
	}
	
	function getConnectionCount()
	{
		return($this->connection_count);
	}
	
	function setConnectionLimit($limit)
	{
		$this->max_connections = $limit;
	}
	
	//  This will stop the entire socket server (client and server sockets).
	function stop()
	{
		
	}
}
?>