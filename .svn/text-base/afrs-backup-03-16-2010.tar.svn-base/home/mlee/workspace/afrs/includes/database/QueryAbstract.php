<?php
// Licensed under GPLv3.  Copyright Mike Lee 2008-2009.

Class QueryAbstract
{
	protected 	$dblink, 
				$query,
				$query_link,   
				$result_size;
			
	protected $result = array();
			
	function __construct($dblink)
	{
			$this->dblink = $dblink;
			$this->query = $query;
	}
	
	function getResultSize ()
	{
		return result_size;
	}
}

?>