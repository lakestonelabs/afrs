#!/usr/bin/php 
<?php

echo "IN_ATTRIB:  " . IN_ATTRIB . "\n";
echo "IN_CLOSE_WRITE:  " . IN_CLOSE_WRITE . "\n";
echo "IN_CLOSE_NOWRITE:  " . IN_CLOSE_NOWRITE . "\n";
echo "IN_CREATE:  " . IN_CREATE . "\n";
echo "IN_DELETE:  " . IN_DELETE . "\n";
echo "IN_DELETE_SELF:  " . IN_DELETE_SELF . "\n";
echo "IN_MODIFY:  " . IN_MODIFY . "\n";
echo "IN_MOVE_SELF:  " . IN_MOVE_SELF . "\n";
echo "IN_MOVED_FROM:  " . IN_MOVED_FROM . "\n";
echo "IN_MOVED_TO:  " . IN_MOVED_TO . "\n";
echo "IN_OPEN:  " . IN_OPEN . "\n";
echo "IN_ALL_EVENTS:  " . IN_ALL_EVENTS . "\n";
echo "IN_MOVE:  " . IN_MOVE . "\n";
echo "IN_CLOSE:  " . IN_CLOSE . "\n";
echo "\n";
echo "IN_MODIFY:  " . IN_MODIFY . "\n";
echo "IN_ATTRIB:  " . IN_ATTRIB . "\n";
echo "IN_CLOSE_WRITE:  " . IN_CLOSE_WRITE . "\n";
echo "IN_CLOSE_NOWRITE:  " . IN_CLOSE_NOWRITE . "\n";
echo "IN_CLOSE:  " . IN_CLOSE . "\n";
echo "IN_OPEN:  " . IN_OPEN . "\n";
echo "IN_MOVED_FROM:  " . IN_MOVED_FROM . "\n";
echo "IN_MOVED_TO:  " . IN_MOVED_TO . "\n";
echo "IN_MOVE:  " . IN_MOVE . "\n";
echo "IN_CREATE:  " . IN_CREATE . "\n";
echo "IN_DELETE:  " . IN_DELETE . "\n";
echo "IN_DELETE_SELF:  " . IN_DELETE_SELF . "\n";
echo "IN_MOVE_SELF:  " . IN_MOVE_SELF . "\n";
echo "IN_ALL_EVENTS:  " . IN_ALL_EVENTS . "\n";
echo "IN_IGNORED: " . IN_IGNORED . "\n";
echo "IN_ISDIR: " . IN_ISDIR . "\n";
echo "IN_Q_OVERFLOW: " . IN_Q_OVERFLOW . "\n";
echo "IN_UNMOUNT: " . IN_UNMOUNT . "\n";
echo "IN_DONT_FOLLOW: " . IN_DONT_FOLLOW . "\n";
echo "IN_MASK_ADD: " . IN_MASK_ADD . "\n";
echo "IN_ONESHOT: " . IN_ONESHOT . "\n";
echo "IN_ONLYDIR: " . IN_ONLYDIR . "\n";


?>
