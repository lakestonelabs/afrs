#!/usr/bin/php 
<?
require_once("includes/system/Message.php");
require_once("includes/system/Dispatcher.php");

$socket = stream_socket_client("tcp://localhost:4746", $errno, $errstr, 15);
$this_message_object = new Message($socket);
$this_message_object->setTransmitCommand("REGISTER");

$dispatcher = new Dispatcher();
$dispatcher->dispatch($this_message_object);

$query->runQuery("select value from tbl_registry where name = 'membership_password'");

?>