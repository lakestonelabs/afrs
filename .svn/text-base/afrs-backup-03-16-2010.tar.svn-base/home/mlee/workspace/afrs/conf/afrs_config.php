<?php
// Licensed under GPLv3.  Copyright Mike Lee 2008-2009.

$afrs_home = "/home/mlee/worksapce/afrs";  // Where afrs and its dependent files reside.
$afrs_watcher_frequency = 500000;  // The time in msec between notification checks.  Default here is .5 seconds.
$log_dir = "/var/log/afrs";  // This is the location to write log events if unable to store them in the database.


// Mysql database login information.
$dbtype = "mysql";
$dbhost = "localhost";
$dbname = "afrs";
$dbuser = "afrs";
$dbpassword = "afrspassword";

?>